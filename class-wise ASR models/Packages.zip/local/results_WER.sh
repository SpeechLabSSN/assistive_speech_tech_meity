#!/bin/bash

# this RESULTS file was obtained by Haihua Xu in July 2013.

for x in exp/*/decode*; do [ -d $x ] && [[ $x =~ "$1" ]] && grep WER $x/wer_* | utils/best_wer.sh; done
exit 0

#!/bin/tcsh -f


rm -f data/local/dict/phone_list data/local/dict/optional_silence.txt data/local/dict/silence_phones.txt data/local/dict/nonsilence_phones.txt data/local/dict/extra_questions.txt
###### create directory for dictionary files ####
mkdir data/local

mkdir data/local/dict

########### to prepare local/dict required files ##############
##### get the unique phones from a moderate speaker by getting all the phones from their lab files
ls -a ssn_tdsc_data/moderate/FAM/label/*.lab  >> temp1
set num_lab_files =  `cat temp1 |wc -l`
echo $num_lab_files
set j = 1
while ($j <= $num_lab_files)
	
	cat ssn_tdsc_data/moderate/FAM/label/FAM$j.lab | cut -d " " -f3 >> temp2   #### get the phones from lab files
	@ j++
end
cat temp2|sort|uniq > data/local/dict/phone_list #### get the unique phones

echo "SIL" > data/local/dict/optional_silence.txt #### has only SIL

echo "SIL" > data/local/dict/silence_phones.txt   #### has only SIL

cat temp2|sort|uniq > data/local/dict/nonsilence_phones.txt 
grep -v "SIL" data/local/dict/nonsilence_phones.txt > temp.txt && mv temp.txt data/local/dict/nonsilence_phones.txt  #### has only non-SIL phones

echo "SIL" > data/local/dict/extra_questions.txt
tr '\n' ' ' < data/local/dict/nonsilence_phones.txt >> data/local/dict/extra_questions.txt     #### to get a tt file with SIL in line one and the phones in line-2 which are horizontally separated.



#!/bin/tcsh -f



#lines=$(wc -l < ./mild_wave_list)
#num_lines_80=$((lines * 80 / 100))
#num_lines_20=$((lines * 20 / 100))

#echo $num_lines_80
#echo $num_lines_20

# create directories #########
mkdir data
mkdir data/data
mkdir data/data/test
mkdir data/data/train

if ($# != 2) then
echo "argument 1 = wavefile_list"
echo "argument 2 = speaker_list"
exit(-1)
endif


set lines = `cat $1 | wc -l`


echo $lines

set train_data_80 = `expr $lines \* 80 / 100`
echo "train_data"
echo $train_data_80
set test_data_20 = `expr $lines \* 20 / 100`
echo "test_data"
echo $test_data_20


#to separate train and test wavefiles for each dysarthric speaker
set i = 1
set speaker_num = `cat $2 | wc -l`
echo $speaker_num

rm -f data/data/train/uttID_text data/data/test/uttID_text data/data/train/train_trans data/data/test/test_trans data/data/train/uttID data/data/test/uttID data/data/train/utt2spk data/data/train/spk2utt data/data/test/utt2spk data/data/test/spk2utt data/data/train/train_wav.scp data/data/test/test_wav.scp

while ($i <= $speaker_num)
rm -f temp temp1 temp2 temp3 temp4 temp5 temp6 temp7 temp8 temp9 temp10 temp11
set speaker = `cat $2 | head -$i | tail -1`
echo $speaker

	ls -a ssn_tdsc_data/moderate/$speaker/audio/*.wav | cut -d "/" -f5 | cut -d "." -f1 >> temp
	cat temp | head -$train_data_80 >> temp1
	cat temp | tail -$test_data_20 >> temp2
	
	awk '{print}' ssn_tdsc_data/moderate/$speaker/prompts/*.txt >> temp3
	cat temp3 | head -$train_data_80 >> temp4
	cat temp3 | tail -$test_data_20 >> temp5
	
		
	paste temp1 temp4  >> data/data/train/uttID_text
	paste temp2 temp5  >> data/data/test/uttID_text
	
	
	cat temp4 >> data/data/train/train_trans
	cat temp5 >> data/data/test/test_trans
	
	cat temp1 >> data/data/train/uttID
	cat temp2 >> data/data/test/uttID
	
		
	ls -a ssn_tdsc_data/moderate/$speaker/audio/*.wav | cut -d "/" -f3 >> temp8
	cat temp8 | head -$train_data_80 >> temp6
	cat temp8 | tail -$test_data_20 >> temp7
	
	paste temp1 temp6 >> data/data/train/utt2spk
	#paste temp6 temp1 >> data/data/train/spk2utt
	 
	paste temp2 temp7 >> data/data/test/utt2spk
	#paste temp7 temp2 >> data/data/test/spk2utt
	
	
	ls -a ssn_tdsc_data/moderate/$speaker/audio/*.wav  >> temp9
	cat temp9 | head -$train_data_80 >> temp10
	cat temp9 | tail -$test_data_20 >> temp11
	
	paste temp1 temp10 >> data/data/train/train_wav.scp 
	paste temp2 temp11 >> data/data/test/test_wav.scp
	#rm -rf temp
	
	echo 'hai'
	
@ i++
end

./utils/utt2spk_to_spk2utt.pl data/data/train/utt2spk > data/data/train/spk2utt
./utils/utt2spk_to_spk2utt.pl data/data/test/utt2spk > data/data/test/spk2utt

rm -f temp temp1 temp2 temp3 temp4 temp5 temp6 temp7 temp8 temp9 temp10 temp11 temp12



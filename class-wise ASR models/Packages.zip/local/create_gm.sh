#!/bin/tcsh -f
### this code accepts the complete text as input and creates lm_train.txt as output which is the file needed for grammer model


if ($# != 1) then
echo "argument 1 = complete text"
exit(-1)
endif

set lines = `cat $1 | wc -l`
set i = 1

while ($i <= $lines)
set text_line = `cat $1 | head -$i | tail -1`

echo "<s> $text_line </s>" >> temp

@ i ++
end
mv temp lm_train.txt

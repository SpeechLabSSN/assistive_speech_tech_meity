#!/bin/tcsh -f



echo '------------------ language model ------------------------------- '
rm data/data/lexicon_wrd_phn.txt
######## to create lexicon.txt required for language modelling #################

ls -a ssn_tdsc_data/moderate/FAM/label/*.lab  >> temp1
set num_lab_files =  `cat temp1 |wc -l`
echo $num_lab_files
set j = 1
while ($j <= $num_lab_files)
	
	cat ssn_tdsc_data/moderate/FAM/label/FAM$j.lab | cut -d " " -f3 > temp2  ### to get phones from all label files
	tr '\n' ' ' < temp2 > temp3  ###### to get the phones in horisontal line
	tr 'SIL' '\n' < temp3 > temp4 ##### to remove SIL and group the phones into words with each phone saparated by space
	sed '/^ *$/d' temp4 >> temp5  ####### to remove the empt lines
	 #sed '/^$/d' temp4 >> temp5
@ j++
rm -f temp2 temp3 temp4 
end
sed "s/^[ \t]*//" -i temp5  ######### to remove the white space in the begining of the phone and overwrite the files

tr ' ' '\n' < ssn_tdsc_data/complete_text > temp6  ##### get the file with text splitted into words in each line
paste temp6 temp5 >> temp7  

cat temp7|sort|uniq > data/data/lexicon_wrd_phn.txt
echo "SIL" ' ' "SIL" >> data/data/lexicon_wrd_phn.txt
mv data/data/lexicon_wrd_phn.txt data/local/dict/lexicon.txt
cp data/local/dict/lexicon.txt  data/data/lexicon_wrd_phn.txt

rm -f temp1 temp2 temp3 temp4 temp5 temp6 temp7 

#echo 'for creating dictionary ---------'
#sed -i 's/\t/ /g' data/local/data/train_phn.trans 
#sed -i 's/\t/ /g' data/local/data/test_phn.trans 
